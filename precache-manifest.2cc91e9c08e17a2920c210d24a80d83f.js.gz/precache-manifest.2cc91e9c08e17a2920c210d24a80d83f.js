self.__precacheManifest = [
  {
    "revision": "bfee9e85c7545ba52046",
    "url": "/js/chunk-2d22d3f5.63febfbb.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "4782539b73b5ec062537",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "06d7fd9ecf81b72ab84c",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "d6e726fffcd4a4ba9fe5",
    "url": "/js/chunk-2d0c0895.5da178e9.js"
  },
  {
    "revision": "f7f9d0a900af10b82f0e",
    "url": "/js/chunk-2d21ef2c.f56265ea.js"
  },
  {
    "revision": "9d859b96e9999714d6bf",
    "url": "/js/app.147f70a2.js"
  },
  {
    "revision": "06d7fd9ecf81b72ab84c",
    "url": "/js/chunk-1d69d99a.afabe326.js"
  },
  {
    "revision": "4782539b73b5ec062537",
    "url": "/js/chunk-6b3e4ad5.17e3387c.js"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "f1eb34e4c3e13416fb45ed7ab6b62a70",
    "url": "/index.html"
  },
  {
    "revision": "9d859b96e9999714d6bf",
    "url": "/css/app.1cb36932.css"
  }
];