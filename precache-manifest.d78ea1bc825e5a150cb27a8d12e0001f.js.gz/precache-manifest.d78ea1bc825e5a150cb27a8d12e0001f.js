self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "d5b753dfc9ef2bba5b8f",
    "url": "/js/chunk-b8395d54.1c12302c.js"
  },
  {
    "revision": "1e849feb054d7a1a8ad4",
    "url": "/js/chunk-6b3e4ad5.ed5c574a.js"
  },
  {
    "revision": "37727cb273f8551abbc7",
    "url": "/js/app.6a40ce63.js"
  },
  {
    "revision": "ea6c83182550d52f6b4126f1094eb0e7",
    "url": "/index.html"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "d5b753dfc9ef2bba5b8f",
    "url": "/css/chunk-b8395d54.abf43bc7.css"
  },
  {
    "revision": "1e849feb054d7a1a8ad4",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "37727cb273f8551abbc7",
    "url": "/css/app.1cb36932.css"
  }
];