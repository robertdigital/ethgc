self.__precacheManifest = [
  {
    "revision": "55464e473f356ec2b458",
    "url": "/js/chunk-2d22d3f5.aa32639b.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "485df5d0e1b52a2ff81d",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "c3b35932d663dc28d183",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "2464f1f97723a0b871b3",
    "url": "/js/chunk-2d0c0895.5d66b889.js"
  },
  {
    "revision": "bbe88901b32860aa978b",
    "url": "/js/chunk-2d21ef2c.802023e2.js"
  },
  {
    "revision": "977f2d3ab9f3af334b19",
    "url": "/js/app.71bfc3e1.js"
  },
  {
    "revision": "c3b35932d663dc28d183",
    "url": "/js/chunk-1d69d99a.532f3fa7.js"
  },
  {
    "revision": "485df5d0e1b52a2ff81d",
    "url": "/js/chunk-6b3e4ad5.2f384319.js"
  },
  {
    "revision": "8e5dfd0f7fc3d27bd59f",
    "url": "/js/chunk-vendors.57144cc6.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "9b954cab7dedec35c64670a6c2811692",
    "url": "/index.html"
  },
  {
    "revision": "977f2d3ab9f3af334b19",
    "url": "/css/app.38c166df.css"
  }
];