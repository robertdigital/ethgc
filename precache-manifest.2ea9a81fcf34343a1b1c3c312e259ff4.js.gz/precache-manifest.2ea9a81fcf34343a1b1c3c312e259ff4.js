self.__precacheManifest = [
  {
    "revision": "143e995713830aee518f",
    "url": "/js/chunk-2d22d3f5.fd249acc.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "da262f9c1a361941ad73",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "46ca9b8380f53581b54c",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "1866e2ad6772efbe4ee4",
    "url": "/js/chunk-2d0c0895.4c3273f6.js"
  },
  {
    "revision": "7e56231aa6364f91c223",
    "url": "/js/chunk-2d21ef2c.e89b2de2.js"
  },
  {
    "revision": "6525d8901e17337d4fa2",
    "url": "/js/app.1221d5bf.js"
  },
  {
    "revision": "46ca9b8380f53581b54c",
    "url": "/js/chunk-1d69d99a.f44b7caf.js"
  },
  {
    "revision": "da262f9c1a361941ad73",
    "url": "/js/chunk-6b3e4ad5.6d153c9e.js"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "bfe5457d139a6895f92f467688ab7b94",
    "url": "/index.html"
  },
  {
    "revision": "6525d8901e17337d4fa2",
    "url": "/css/app.1cb36932.css"
  }
];