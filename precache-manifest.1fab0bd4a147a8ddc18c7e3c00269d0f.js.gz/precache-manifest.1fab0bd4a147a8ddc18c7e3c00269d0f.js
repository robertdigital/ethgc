self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b3cb1a9257d2647e70bc",
    "url": "/css/app.129a0abd.css"
  },
  {
    "revision": "460cbea39f1f77519d99",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "3c1b0c241f46b488d2d0",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "99cca1b77bad8ebb5f0bcfef9ca3c288",
    "url": "/index.html"
  },
  {
    "revision": "b3cb1a9257d2647e70bc",
    "url": "/js/app.bdd84c1f.js"
  },
  {
    "revision": "d520b71d8a74b8b173b0",
    "url": "/js/chunk-2d0c0895.87e831b2.js"
  },
  {
    "revision": "659da0c812cab66c580a",
    "url": "/js/chunk-2d21ef2c.791728d0.js"
  },
  {
    "revision": "9f4cceaa3a56a23adf15",
    "url": "/js/chunk-2d22d3f5.0e47e283.js"
  },
  {
    "revision": "460cbea39f1f77519d99",
    "url": "/js/chunk-83caf4ba.d5c96374.js"
  },
  {
    "revision": "3c1b0c241f46b488d2d0",
    "url": "/js/chunk-ad949e22.4200602c.js"
  },
  {
    "revision": "4850d22564389ae90b62",
    "url": "/js/chunk-vendors.7ec87fa1.js"
  },
  {
    "revision": "fa3d29640cfc6d45c9be154b0f4a5aff",
    "url": "/js/chunk-vendors.7ec87fa1.js.LICENSE"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);