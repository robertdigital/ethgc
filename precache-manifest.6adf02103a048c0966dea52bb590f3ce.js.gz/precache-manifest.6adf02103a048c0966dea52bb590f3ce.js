self.__precacheManifest = [
  {
    "revision": "fb068fe52afd3b856d93",
    "url": "/js/chunk-c8106760.262bee12.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "fce818ab6f3bba72c1ad",
    "url": "/js/chunk-vendors.83d3b327.js"
  },
  {
    "revision": "18b1bf5a5fa45e381062",
    "url": "/js/chunk-b9fa66ee.9e24d90c.js"
  },
  {
    "revision": "89ee9b6fec55150dfbd3",
    "url": "/js/app.29b676a6.js"
  },
  {
    "revision": "c2d8b3be01a0e10115a4a5fe5fcf981b",
    "url": "/index.html"
  },
  {
    "revision": "539ad89308048d6d9ee363d2bff12eee",
    "url": "/img/logo.539ad893.png"
  },
  {
    "revision": "fce818ab6f3bba72c1ad",
    "url": "/css/chunk-vendors.f1c442fc.css"
  },
  {
    "revision": "fb068fe52afd3b856d93",
    "url": "/css/chunk-c8106760.e3010269.css"
  },
  {
    "revision": "18b1bf5a5fa45e381062",
    "url": "/css/chunk-b9fa66ee.e3010269.css"
  },
  {
    "revision": "89ee9b6fec55150dfbd3",
    "url": "/css/app.775afb2c.css"
  }
];