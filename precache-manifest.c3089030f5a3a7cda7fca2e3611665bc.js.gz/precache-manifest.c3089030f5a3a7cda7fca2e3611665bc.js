self.__precacheManifest = [
  {
    "revision": "c82da55ba5e291112f88",
    "url": "/js/chunk-2d22d3f5.32de4d40.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "d6293f2a80d9b2302d73",
    "url": "/css/chunk-5a3ddab8.1e7edb93.css"
  },
  {
    "revision": "e1689ff65838eb10962a",
    "url": "/css/chunk-2618e298.f1378d79.css"
  },
  {
    "revision": "dad7f9efd5510def02e0",
    "url": "/js/chunk-2d0c0895.92141c52.js"
  },
  {
    "revision": "24f8f036012475076a23",
    "url": "/js/chunk-2d21ef2c.927b731a.js"
  },
  {
    "revision": "51102dd7effd2815fc31",
    "url": "/js/app.89be29b2.js"
  },
  {
    "revision": "e1689ff65838eb10962a",
    "url": "/js/chunk-2618e298.72ae1b7a.js"
  },
  {
    "revision": "d6293f2a80d9b2302d73",
    "url": "/js/chunk-5a3ddab8.97a6a67a.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "5124ce140beed4b3fb33f71fa49aa776",
    "url": "/index.html"
  },
  {
    "revision": "51102dd7effd2815fc31",
    "url": "/css/app.cc4a0117.css"
  }
];