self.__precacheManifest = [
  {
    "revision": "05230df384b4035a3d6b",
    "url": "/js/chunk-2d22d3f5.e5ca0af0.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "a9f264341b17e2bdac0e",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "16f79121241ac95ec1ab",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "6953286b741518a607e8",
    "url": "/js/chunk-2d0c0895.bf0b32bc.js"
  },
  {
    "revision": "484df77411fc84a9fa28",
    "url": "/js/chunk-2d21ef2c.5e962eda.js"
  },
  {
    "revision": "4134f13049a94c6f3a2d",
    "url": "/js/app.c7222cb8.js"
  },
  {
    "revision": "16f79121241ac95ec1ab",
    "url": "/js/chunk-1d69d99a.7574fb77.js"
  },
  {
    "revision": "a9f264341b17e2bdac0e",
    "url": "/js/chunk-6b3e4ad5.78f62219.js"
  },
  {
    "revision": "f92cab3e283b5c51db6e",
    "url": "/js/chunk-vendors.ae1c02d5.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "5f8eacf7481d31b8f7851cd20c30288a",
    "url": "/index.html"
  },
  {
    "revision": "4134f13049a94c6f3a2d",
    "url": "/css/app.38c166df.css"
  }
];