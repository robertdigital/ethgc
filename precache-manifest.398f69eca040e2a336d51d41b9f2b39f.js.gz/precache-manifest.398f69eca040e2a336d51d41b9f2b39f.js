self.__precacheManifest = [
  {
    "revision": "ff2a6b96f5fcd60916c1",
    "url": "/css/chunk-5a3ddab8.1e7edb93.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "ff2a6b96f5fcd60916c1",
    "url": "/js/chunk-5a3ddab8.ff25f4c9.js"
  },
  {
    "revision": "54a3e42e04340319aeff",
    "url": "/css/chunk-2618e298.f1378d79.css"
  },
  {
    "revision": "5e4f04c1da66f7edf5da",
    "url": "/js/chunk-2d0c0895.36b31217.js"
  },
  {
    "revision": "8fee2b3d8a02d1606a09",
    "url": "/js/chunk-2d21ef2c.d4857852.js"
  },
  {
    "revision": "53d185866c308095bebc",
    "url": "/js/chunk-2d22d3f5.1ea99fb0.js"
  },
  {
    "revision": "0cb4bb4cb9c83131fd7f",
    "url": "/js/app.938e37fc.js"
  },
  {
    "revision": "54a3e42e04340319aeff",
    "url": "/js/chunk-2618e298.53e8a2ab.js"
  },
  {
    "revision": "d42d169e29a23d38726d",
    "url": "/js/chunk-vendors.1757327d.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "c10caad9bc6f415abfd18edb8597532f",
    "url": "/js/chunk-vendors.1757327d.js.LICENSE"
  },
  {
    "revision": "ede1e17653c7b7bb107d884811c7a368",
    "url": "/index.html"
  },
  {
    "revision": "0cb4bb4cb9c83131fd7f",
    "url": "/css/app.cc4a0117.css"
  }
];