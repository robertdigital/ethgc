self.__precacheManifest = [
  {
    "revision": "92747ba1b74e076508e0",
    "url": "/js/chunk-2d22d3f5.a9b5f8de.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "0b447dc80a4c3d05700f",
    "url": "/css/chunk-5a3ddab8.1e7edb93.css"
  },
  {
    "revision": "9bf603e1fb465fd59713",
    "url": "/css/chunk-2618e298.f1378d79.css"
  },
  {
    "revision": "f3d2c1409afc57f2a710",
    "url": "/js/chunk-2d0c0895.c1922c21.js"
  },
  {
    "revision": "790406610739d6bdda1f",
    "url": "/js/chunk-2d21ef2c.4a5ca672.js"
  },
  {
    "revision": "91ca7eb35a74a4252dfc",
    "url": "/js/app.1fd6313e.js"
  },
  {
    "revision": "9bf603e1fb465fd59713",
    "url": "/js/chunk-2618e298.2335e70c.js"
  },
  {
    "revision": "0b447dc80a4c3d05700f",
    "url": "/js/chunk-5a3ddab8.15b0a9a8.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "b28d8d25245f30e911b8f7998590bf9c",
    "url": "/index.html"
  },
  {
    "revision": "91ca7eb35a74a4252dfc",
    "url": "/css/app.cc4a0117.css"
  }
];