self.__precacheManifest = [
  {
    "revision": "96474c7ccfde6c89f872",
    "url": "/js/chunk-2d22d3f5.11d4e7fd.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "adff7f52f2ac75769758",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "23cd88b95ac180d07f69",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "80b078a821db3c51f743",
    "url": "/js/chunk-2d0c0895.38313d31.js"
  },
  {
    "revision": "75648e4049b313dccee1",
    "url": "/js/chunk-2d21ef2c.b38b40ab.js"
  },
  {
    "revision": "a7ed7f711669285e5389",
    "url": "/js/app.0e537218.js"
  },
  {
    "revision": "23cd88b95ac180d07f69",
    "url": "/js/chunk-1d69d99a.2213d1e4.js"
  },
  {
    "revision": "adff7f52f2ac75769758",
    "url": "/js/chunk-6b3e4ad5.b89db191.js"
  },
  {
    "revision": "722a2805406d3d325389",
    "url": "/js/chunk-vendors.5871b7b0.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "965319ade650ed15ec5ab4aa053a48d7",
    "url": "/index.html"
  },
  {
    "revision": "a7ed7f711669285e5389",
    "url": "/css/app.38c166df.css"
  }
];