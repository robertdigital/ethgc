self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "f280b7a3519f486be951",
    "url": "/js/chunk-b8395d54.c739c163.js"
  },
  {
    "revision": "ebc9dd37ad92ab797fd4",
    "url": "/js/chunk-6b3e4ad5.d19f1c83.js"
  },
  {
    "revision": "ecd92a183d826f4114f5",
    "url": "/js/app.49cf5a62.js"
  },
  {
    "revision": "327eb9d7f213fc01d78f26cd3e4238e8",
    "url": "/index.html"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "f280b7a3519f486be951",
    "url": "/css/chunk-b8395d54.abf43bc7.css"
  },
  {
    "revision": "ebc9dd37ad92ab797fd4",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "ecd92a183d826f4114f5",
    "url": "/css/app.1cb36932.css"
  }
];