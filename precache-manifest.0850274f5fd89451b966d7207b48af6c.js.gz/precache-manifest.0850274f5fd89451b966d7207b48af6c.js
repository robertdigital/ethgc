self.__precacheManifest = [
  {
    "revision": "ba2c798677a81f0cebbd",
    "url": "/js/chunk-2d22d3f5.63651715.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "e2a71ebd1ec1dfbd18cd",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "f79320322571b98a9b3e",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "1a41bc1a7941ab3b9a27",
    "url": "/js/chunk-2d0c0895.3b26d12f.js"
  },
  {
    "revision": "57701601ed5fa43a2bc3",
    "url": "/js/chunk-2d21ef2c.432c6664.js"
  },
  {
    "revision": "f9665d8773bfba1041a7",
    "url": "/js/app.767f45f7.js"
  },
  {
    "revision": "f79320322571b98a9b3e",
    "url": "/js/chunk-1d69d99a.d958ed45.js"
  },
  {
    "revision": "e2a71ebd1ec1dfbd18cd",
    "url": "/js/chunk-6b3e4ad5.efdbfe8b.js"
  },
  {
    "revision": "f92cab3e283b5c51db6e",
    "url": "/js/chunk-vendors.ae1c02d5.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "bff5d6fdd2a6b6f35fae4ec6e7b05aa6",
    "url": "/index.html"
  },
  {
    "revision": "f9665d8773bfba1041a7",
    "url": "/css/app.38c166df.css"
  }
];