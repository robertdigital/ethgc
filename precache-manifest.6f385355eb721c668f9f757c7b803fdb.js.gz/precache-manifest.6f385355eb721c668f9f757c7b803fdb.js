self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "582cad003ef78a78f3cc",
    "url": "/css/app.129a0abd.css"
  },
  {
    "revision": "2bfc6a1498e79a763b2f",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "a24b91b077a06bda03c3",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "96e74739365626bdbb812231f409df27",
    "url": "/index.html"
  },
  {
    "revision": "582cad003ef78a78f3cc",
    "url": "/js/app.b58b87a2.js"
  },
  {
    "revision": "e5f12824875e2d3850e8",
    "url": "/js/chunk-2d0c0895.91f1d3f5.js"
  },
  {
    "revision": "6105305b3c2eecff3c9a",
    "url": "/js/chunk-2d21ef2c.0de9c8ac.js"
  },
  {
    "revision": "4c1d1ba2f8301eb4c7df",
    "url": "/js/chunk-2d22d3f5.c3c3f565.js"
  },
  {
    "revision": "2bfc6a1498e79a763b2f",
    "url": "/js/chunk-83caf4ba.39a723e6.js"
  },
  {
    "revision": "a24b91b077a06bda03c3",
    "url": "/js/chunk-ad949e22.39dc05ac.js"
  },
  {
    "revision": "4266334db4e2566380f4",
    "url": "/js/chunk-vendors.aa22c20b.js"
  },
  {
    "revision": "fa3d29640cfc6d45c9be154b0f4a5aff",
    "url": "/js/chunk-vendors.aa22c20b.js.LICENSE"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);