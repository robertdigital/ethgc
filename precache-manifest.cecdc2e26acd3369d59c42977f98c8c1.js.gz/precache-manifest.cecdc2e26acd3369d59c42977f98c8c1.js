self.__precacheManifest = [
  {
    "revision": "e7d9c281dfa10a0f89de",
    "url": "/js/chunk-2d22d3f5.7ff526a9.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "deb1528f4c82c72a2ed4",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "1a77529356f5b369cc92",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "31c0c242408b1fd30023",
    "url": "/js/chunk-2d0c0895.95fab71a.js"
  },
  {
    "revision": "cdf3b60dc1515b325c99",
    "url": "/js/chunk-2d21ef2c.d48dee42.js"
  },
  {
    "revision": "dd560e2a9686493b314b",
    "url": "/js/app.1e923cef.js"
  },
  {
    "revision": "1a77529356f5b369cc92",
    "url": "/js/chunk-1d69d99a.1683747e.js"
  },
  {
    "revision": "deb1528f4c82c72a2ed4",
    "url": "/js/chunk-6b3e4ad5.55862410.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "2c3b6ac60054b8cccefbce608aa5c0ac",
    "url": "/index.html"
  },
  {
    "revision": "dd560e2a9686493b314b",
    "url": "/css/app.eb48c4ad.css"
  }
];