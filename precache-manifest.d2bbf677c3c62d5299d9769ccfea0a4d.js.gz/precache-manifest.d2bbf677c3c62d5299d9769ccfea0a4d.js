self.__precacheManifest = [
  {
    "revision": "c365dd3dd849ee0fe00a",
    "url": "/js/chunk-2d22d3f5.2ab9c3f8.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "1360960a967f19bbda47",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "3efd20ea2e4d99aabc3d",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "0834e1f7cce9ea09ac8f",
    "url": "/js/chunk-2d0c0895.50f1bc02.js"
  },
  {
    "revision": "e19cdf72badbdb0711da",
    "url": "/js/chunk-2d21ef2c.fea1d726.js"
  },
  {
    "revision": "f88b841d5e8e6d49cf28",
    "url": "/js/app.98d75d7d.js"
  },
  {
    "revision": "3efd20ea2e4d99aabc3d",
    "url": "/js/chunk-1d69d99a.14903e4c.js"
  },
  {
    "revision": "1360960a967f19bbda47",
    "url": "/js/chunk-6b3e4ad5.344a11ed.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "d9cfd73b34a8fe55266f319565e2c242",
    "url": "/index.html"
  },
  {
    "revision": "f88b841d5e8e6d49cf28",
    "url": "/css/app.eb48c4ad.css"
  }
];