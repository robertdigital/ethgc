self.__precacheManifest = [
  {
    "revision": "054f82e9c44396d94942",
    "url": "/js/chunk-2d22d3f5.ffa33f39.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "e509963923871a174d4c",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "646813ca24d192c60ede",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "c1027d605e4d2ec3058d",
    "url": "/js/chunk-2d0c0895.fa6b80b9.js"
  },
  {
    "revision": "0ea1321fb6b8488fbf83",
    "url": "/js/chunk-2d21ef2c.0651338e.js"
  },
  {
    "revision": "ab019ab0e78c170790bd",
    "url": "/js/app.a2e4ff40.js"
  },
  {
    "revision": "646813ca24d192c60ede",
    "url": "/js/chunk-1d69d99a.e6d65633.js"
  },
  {
    "revision": "e509963923871a174d4c",
    "url": "/js/chunk-6b3e4ad5.b8cfdc98.js"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "fc20f2668753365b9e8199fb27a02b4f",
    "url": "/index.html"
  },
  {
    "revision": "ab019ab0e78c170790bd",
    "url": "/css/app.1cb36932.css"
  }
];