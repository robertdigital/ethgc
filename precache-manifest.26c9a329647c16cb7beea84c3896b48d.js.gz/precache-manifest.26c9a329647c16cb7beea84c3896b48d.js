self.__precacheManifest = [
  {
    "revision": "b5bff04db0d56ca75a58",
    "url": "/js/chunk-2d22d3f5.4d2fdd99.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "23266e64406b5ec69183",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "8c7cd32132bbfddd1ea3",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "3a315edd63abd11b1daa",
    "url": "/js/chunk-2d0c0895.7e5d8a83.js"
  },
  {
    "revision": "a64de58a0f60210044a2",
    "url": "/js/chunk-2d21ef2c.27432b0d.js"
  },
  {
    "revision": "b1feecba3310e1606d22",
    "url": "/js/app.24040bea.js"
  },
  {
    "revision": "8c7cd32132bbfddd1ea3",
    "url": "/js/chunk-1d69d99a.28451bd4.js"
  },
  {
    "revision": "23266e64406b5ec69183",
    "url": "/js/chunk-6b3e4ad5.540f712d.js"
  },
  {
    "revision": "8e5dfd0f7fc3d27bd59f",
    "url": "/js/chunk-vendors.57144cc6.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "91c84cca1882f19ef986f3edd8910305",
    "url": "/index.html"
  },
  {
    "revision": "b1feecba3310e1606d22",
    "url": "/css/app.eb48c4ad.css"
  }
];