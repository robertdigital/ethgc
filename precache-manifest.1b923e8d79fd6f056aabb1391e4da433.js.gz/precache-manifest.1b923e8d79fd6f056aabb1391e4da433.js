self.__precacheManifest = [
  {
    "revision": "adfe97b50614b25e22ce",
    "url": "/js/chunk-2d22d3f5.c9201125.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "17d074a2f52d65a11dd6",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "93c7afb655fc99582f95",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "96c370b80833c1678385",
    "url": "/js/chunk-2d0c0895.560667e8.js"
  },
  {
    "revision": "7f8d2e18410109e8fb9c",
    "url": "/js/chunk-2d21ef2c.3884783e.js"
  },
  {
    "revision": "44b965ab0483bb3b6cd0",
    "url": "/js/app.a0527c97.js"
  },
  {
    "revision": "93c7afb655fc99582f95",
    "url": "/js/chunk-1d69d99a.cfdaa3cf.js"
  },
  {
    "revision": "17d074a2f52d65a11dd6",
    "url": "/js/chunk-6b3e4ad5.10e1c032.js"
  },
  {
    "revision": "84d07cc51f00a2a8264d",
    "url": "/js/chunk-vendors.bd13ebab.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "6c6228d2ab7f082618e710d636827150",
    "url": "/index.html"
  },
  {
    "revision": "44b965ab0483bb3b6cd0",
    "url": "/css/app.1cb36932.css"
  }
];