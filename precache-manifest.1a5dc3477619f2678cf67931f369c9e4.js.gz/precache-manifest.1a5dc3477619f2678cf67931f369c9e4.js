self.__precacheManifest = [
  {
    "revision": "b3e54c6c1815a4ef1c30",
    "url": "/js/chunk-2d22d3f5.eb204649.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "2d1bfb8ebd9824078bd0",
    "url": "/css/chunk-5a3ddab8.1e7edb93.css"
  },
  {
    "revision": "70ac6b02387a0e81e1d5",
    "url": "/css/chunk-2618e298.f1378d79.css"
  },
  {
    "revision": "544d03a35aac6a182687",
    "url": "/js/chunk-2d0c0895.62e92f93.js"
  },
  {
    "revision": "f93561af5f2b393a7d21",
    "url": "/js/chunk-2d21ef2c.99949c05.js"
  },
  {
    "revision": "9995c97dd8d2b0f696a0",
    "url": "/js/app.585f910d.js"
  },
  {
    "revision": "70ac6b02387a0e81e1d5",
    "url": "/js/chunk-2618e298.2c2ef6bb.js"
  },
  {
    "revision": "2d1bfb8ebd9824078bd0",
    "url": "/js/chunk-5a3ddab8.b14b9f86.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "15c01d5f1c600299ee3e50fc5c7390c0",
    "url": "/index.html"
  },
  {
    "revision": "9995c97dd8d2b0f696a0",
    "url": "/css/app.cc4a0117.css"
  }
];