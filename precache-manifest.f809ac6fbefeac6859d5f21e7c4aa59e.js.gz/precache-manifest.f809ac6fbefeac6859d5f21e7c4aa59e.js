self.__precacheManifest = [
  {
    "revision": "565c93afcc6a7ff53c4a",
    "url": "/css/chunk-5a3ddab8.1e7edb93.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "565c93afcc6a7ff53c4a",
    "url": "/js/chunk-5a3ddab8.2dbd31f1.js"
  },
  {
    "revision": "69224f3680693572e981",
    "url": "/css/chunk-2618e298.f1378d79.css"
  },
  {
    "revision": "42d5666b38fed705012c",
    "url": "/js/chunk-2d0c0895.438250b9.js"
  },
  {
    "revision": "49d42a816b32cd06a3af",
    "url": "/js/chunk-2d21ef2c.34270547.js"
  },
  {
    "revision": "6b0b4219e8747e3c0e59",
    "url": "/js/chunk-2d22d3f5.f01d46bd.js"
  },
  {
    "revision": "0efdb5c6089e177580d7",
    "url": "/js/app.33086d70.js"
  },
  {
    "revision": "69224f3680693572e981",
    "url": "/js/chunk-2618e298.534c7ac3.js"
  },
  {
    "revision": "4f800ab31b8a3aed63b8",
    "url": "/js/chunk-vendors.625daa99.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "c10caad9bc6f415abfd18edb8597532f",
    "url": "/js/chunk-vendors.625daa99.js.LICENSE"
  },
  {
    "revision": "8c54f5b06cba4775e5e116e2ef44778f",
    "url": "/index.html"
  },
  {
    "revision": "0efdb5c6089e177580d7",
    "url": "/css/app.cc4a0117.css"
  }
];