self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "72677345701ec1cb506f",
    "url": "/css/app.129a0abd.css"
  },
  {
    "revision": "8aa0f58db47d9a813d68",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "4bf3c19efa42f83809d4",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "360837dda5dbf21016496ed55938064a",
    "url": "/index.html"
  },
  {
    "revision": "72677345701ec1cb506f",
    "url": "/js/app.c1a4417b.js"
  },
  {
    "revision": "e7ba19aab216b49fba30",
    "url": "/js/chunk-2d0c0895.b759b6b3.js"
  },
  {
    "revision": "47cd8ddc6ccc6b3d05d1",
    "url": "/js/chunk-2d21ef2c.ad406545.js"
  },
  {
    "revision": "f5e2110c3d7589471d05",
    "url": "/js/chunk-2d22d3f5.1d561c9e.js"
  },
  {
    "revision": "8aa0f58db47d9a813d68",
    "url": "/js/chunk-83caf4ba.9d5cde8e.js"
  },
  {
    "revision": "4bf3c19efa42f83809d4",
    "url": "/js/chunk-ad949e22.ca469ff2.js"
  },
  {
    "revision": "76e2b6f4998764efeb86",
    "url": "/js/chunk-vendors.4b8676b7.js"
  },
  {
    "revision": "fa3d29640cfc6d45c9be154b0f4a5aff",
    "url": "/js/chunk-vendors.4b8676b7.js.LICENSE"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);