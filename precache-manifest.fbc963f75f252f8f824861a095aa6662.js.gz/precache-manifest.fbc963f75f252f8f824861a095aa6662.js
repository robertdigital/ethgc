self.__precacheManifest = [
  {
    "revision": "de05aec598ab9da54e50",
    "url": "/js/chunk-2d22d3f5.707fd8ef.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "55443972ef77659e80a3",
    "url": "/css/chunk-5a3ddab8.1e7edb93.css"
  },
  {
    "revision": "8255a2b5dec60a5e5c9c",
    "url": "/css/chunk-2618e298.f1378d79.css"
  },
  {
    "revision": "31b2c8985239368590b3",
    "url": "/js/chunk-2d0c0895.81400403.js"
  },
  {
    "revision": "46d14873b7e0f4a18299",
    "url": "/js/chunk-2d21ef2c.24bbeafc.js"
  },
  {
    "revision": "789f8c94ceb0ad9cb57c",
    "url": "/js/app.19b596af.js"
  },
  {
    "revision": "8255a2b5dec60a5e5c9c",
    "url": "/js/chunk-2618e298.4d87f0ef.js"
  },
  {
    "revision": "55443972ef77659e80a3",
    "url": "/js/chunk-5a3ddab8.2a88b0a7.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "eaad6465aaf9c35eeda625362f68477d",
    "url": "/index.html"
  },
  {
    "revision": "789f8c94ceb0ad9cb57c",
    "url": "/css/app.cc4a0117.css"
  }
];