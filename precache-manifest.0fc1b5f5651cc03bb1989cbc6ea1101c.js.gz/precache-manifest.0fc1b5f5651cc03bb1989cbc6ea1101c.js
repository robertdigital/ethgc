self.__precacheManifest = [
  {
    "revision": "bf1e3c3864ae98c2cdd2",
    "url": "/js/chunk-2d22d3f5.b2fe4cb5.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "241a9145cf73a62ac9e7",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "af4bcb4c2247a48900e8",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "ada894c0e76cba1e5f6c",
    "url": "/js/chunk-2d0c0895.c1009b82.js"
  },
  {
    "revision": "419f112e5bd9f208db2c",
    "url": "/js/chunk-2d21ef2c.f53d20eb.js"
  },
  {
    "revision": "ff1eb7d7cff68e540854",
    "url": "/js/app.83378136.js"
  },
  {
    "revision": "af4bcb4c2247a48900e8",
    "url": "/js/chunk-1d69d99a.1e3e3354.js"
  },
  {
    "revision": "241a9145cf73a62ac9e7",
    "url": "/js/chunk-6b3e4ad5.0be6f16f.js"
  },
  {
    "revision": "8e5dfd0f7fc3d27bd59f",
    "url": "/js/chunk-vendors.57144cc6.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "ffe86888335d58e73ace3ec2890d45a2",
    "url": "/index.html"
  },
  {
    "revision": "ff1eb7d7cff68e540854",
    "url": "/css/app.38c166df.css"
  }
];