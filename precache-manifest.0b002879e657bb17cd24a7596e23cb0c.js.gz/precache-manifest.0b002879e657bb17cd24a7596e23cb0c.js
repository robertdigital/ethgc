self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "f280b7a3519f486be951",
    "url": "/js/chunk-b8395d54.c739c163.js"
  },
  {
    "revision": "ebc9dd37ad92ab797fd4",
    "url": "/js/chunk-6b3e4ad5.d19f1c83.js"
  },
  {
    "revision": "f9929f4b070b8a2fbd0f",
    "url": "/js/app.1230744c.js"
  },
  {
    "revision": "e18f4cb3a41a7c9dec6609cc83188e59",
    "url": "/index.html"
  },
  {
    "revision": "7d757639afe9d5e8ef3aa423745017af",
    "url": "/img/logo.7d757639.png"
  },
  {
    "revision": "f280b7a3519f486be951",
    "url": "/css/chunk-b8395d54.abf43bc7.css"
  },
  {
    "revision": "ebc9dd37ad92ab797fd4",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "f9929f4b070b8a2fbd0f",
    "url": "/css/app.1cb36932.css"
  }
];