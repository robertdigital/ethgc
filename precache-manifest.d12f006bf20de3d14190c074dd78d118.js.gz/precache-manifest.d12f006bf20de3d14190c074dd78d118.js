self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "48cc00dfd55d29ee4b92",
    "url": "/css/app.129a0abd.css"
  },
  {
    "revision": "b5b319815ef258e623da",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "6ab236eb23ceba89d792",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "a38a01be272de6df82d9151c1e9639b9",
    "url": "/index.html"
  },
  {
    "revision": "48cc00dfd55d29ee4b92",
    "url": "/js/app.53438417.js"
  },
  {
    "revision": "0bfd654a386568eef1e6",
    "url": "/js/chunk-2d0c0895.d25b7e2b.js"
  },
  {
    "revision": "a17e3b3697e25e31c3c6",
    "url": "/js/chunk-2d21ef2c.0f69a5de.js"
  },
  {
    "revision": "31def6c0807bda4f939f",
    "url": "/js/chunk-2d22d3f5.308966f7.js"
  },
  {
    "revision": "b5b319815ef258e623da",
    "url": "/js/chunk-83caf4ba.fa2db429.js"
  },
  {
    "revision": "6ab236eb23ceba89d792",
    "url": "/js/chunk-ad949e22.2c0c256c.js"
  },
  {
    "revision": "5b73f8acbdfc5066e738",
    "url": "/js/chunk-vendors.f362c1b9.js"
  },
  {
    "revision": "fa3d29640cfc6d45c9be154b0f4a5aff",
    "url": "/js/chunk-vendors.f362c1b9.js.LICENSE"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);