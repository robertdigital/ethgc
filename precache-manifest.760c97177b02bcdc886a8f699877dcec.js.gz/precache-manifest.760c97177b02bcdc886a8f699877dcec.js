self.__precacheManifest = [
  {
    "revision": "ed2c82343e9e0fbdad72",
    "url": "/js/chunk-2d22d3f5.4fde8c5c.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "f9ca034cc9473c8c9d2b",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "7dddb723a741ac47b3b6",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "0268ce2abab323a7779a",
    "url": "/js/chunk-2d0c0895.bad4aa83.js"
  },
  {
    "revision": "b1733dc2b4e9c80b4703",
    "url": "/js/chunk-2d21ef2c.3507e4e6.js"
  },
  {
    "revision": "15f75f8e508b08dd515a",
    "url": "/js/app.e8af8938.js"
  },
  {
    "revision": "7dddb723a741ac47b3b6",
    "url": "/js/chunk-1d69d99a.771f6910.js"
  },
  {
    "revision": "f9ca034cc9473c8c9d2b",
    "url": "/js/chunk-6b3e4ad5.ef3ad3fb.js"
  },
  {
    "revision": "f92cab3e283b5c51db6e",
    "url": "/js/chunk-vendors.ae1c02d5.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "03a48687ef2e15fba6287573b573a981",
    "url": "/index.html"
  },
  {
    "revision": "15f75f8e508b08dd515a",
    "url": "/css/app.38c166df.css"
  }
];