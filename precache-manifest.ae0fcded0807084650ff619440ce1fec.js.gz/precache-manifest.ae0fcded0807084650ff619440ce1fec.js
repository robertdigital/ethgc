self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b35c539be7a91b39f318",
    "url": "/css/app.129a0abd.css"
  },
  {
    "revision": "6dfe735b4735472f0a73",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "b4c4cce9f83e94d97aa4",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "332618772779d8e04f687f2c45ddd081",
    "url": "/index.html"
  },
  {
    "revision": "b35c539be7a91b39f318",
    "url": "/js/app.255854bc.js"
  },
  {
    "revision": "c825f5d181642c89ed7d",
    "url": "/js/chunk-2d0c0895.3eddb202.js"
  },
  {
    "revision": "bf9f4922e36a7446d178",
    "url": "/js/chunk-2d21ef2c.73303dc8.js"
  },
  {
    "revision": "bb4699f8e8bb97bb27bd",
    "url": "/js/chunk-2d22d3f5.89af827e.js"
  },
  {
    "revision": "6dfe735b4735472f0a73",
    "url": "/js/chunk-83caf4ba.9a2a9cce.js"
  },
  {
    "revision": "b4c4cce9f83e94d97aa4",
    "url": "/js/chunk-ad949e22.1acb471d.js"
  },
  {
    "revision": "4850d22564389ae90b62",
    "url": "/js/chunk-vendors.7ec87fa1.js"
  },
  {
    "revision": "fa3d29640cfc6d45c9be154b0f4a5aff",
    "url": "/js/chunk-vendors.7ec87fa1.js.LICENSE"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);