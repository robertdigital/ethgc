self.__precacheManifest = [
  {
    "revision": "208f0a827c78cc0ff0ca",
    "url": "/js/chunk-2d22d3f5.c304973a.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "73d38b4f5397d93184b0",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "0c262a4ff331019b3b0a",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "3aa0758cebf92a96db05",
    "url": "/js/chunk-2d0c0895.ef7b2339.js"
  },
  {
    "revision": "aaae0fe15460e7d39fd8",
    "url": "/js/chunk-2d21ef2c.4ab2c35b.js"
  },
  {
    "revision": "8c29fe4c91ec16b4dffb",
    "url": "/js/app.138ec514.js"
  },
  {
    "revision": "0c262a4ff331019b3b0a",
    "url": "/js/chunk-1d69d99a.c906a773.js"
  },
  {
    "revision": "73d38b4f5397d93184b0",
    "url": "/js/chunk-6b3e4ad5.af61e7dd.js"
  },
  {
    "revision": "665d84b69fe8089f88d4",
    "url": "/js/chunk-vendors.a6786cca.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "51eb396eedfaa3d1f5e8c83f6b6e91be",
    "url": "/index.html"
  },
  {
    "revision": "8c29fe4c91ec16b4dffb",
    "url": "/css/app.1cb36932.css"
  }
];