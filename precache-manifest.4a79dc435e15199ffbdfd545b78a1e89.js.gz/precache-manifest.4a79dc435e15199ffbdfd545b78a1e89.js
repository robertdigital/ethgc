self.__precacheManifest = [
  {
    "revision": "0db36c20ccd0423e6faa",
    "url": "/js/chunk-c8106760.8da451bc.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "e8e2788cf7a068c9dbf5",
    "url": "/js/chunk-vendors.1e7ff897.js"
  },
  {
    "revision": "0ff10120fc6eb423f9f1",
    "url": "/js/chunk-b9fa66ee.537fae02.js"
  },
  {
    "revision": "bfd7e11a9e8bac66f693",
    "url": "/js/app.4b39d1ed.js"
  },
  {
    "revision": "d62963d3bc1d6593a1ef9c0098476746",
    "url": "/index.html"
  },
  {
    "revision": "7d757639afe9d5e8ef3aa423745017af",
    "url": "/img/logo.7d757639.png"
  },
  {
    "revision": "e8e2788cf7a068c9dbf5",
    "url": "/css/chunk-vendors.f1c442fc.css"
  },
  {
    "revision": "0db36c20ccd0423e6faa",
    "url": "/css/chunk-c8106760.e3010269.css"
  },
  {
    "revision": "0ff10120fc6eb423f9f1",
    "url": "/css/chunk-b9fa66ee.e3010269.css"
  },
  {
    "revision": "bfd7e11a9e8bac66f693",
    "url": "/css/app.775afb2c.css"
  }
];