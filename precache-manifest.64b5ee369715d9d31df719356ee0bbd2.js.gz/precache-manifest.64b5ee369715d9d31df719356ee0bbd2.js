self.__precacheManifest = [
  {
    "revision": "5988782f1a1901cfc2d4",
    "url": "/js/chunk-2d22d3f5.d4fb0724.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "bb852604472ecf37026c",
    "url": "/css/chunk-6b3e4ad5.e3010269.css"
  },
  {
    "revision": "8830a97f2f1591c30fa4",
    "url": "/css/chunk-1d69d99a.bff7bdfb.css"
  },
  {
    "revision": "93eb67f47b9aa959ad85",
    "url": "/js/chunk-2d0c0895.30241665.js"
  },
  {
    "revision": "2eb19eb13415e7c76537",
    "url": "/js/chunk-2d21ef2c.82e6b7f3.js"
  },
  {
    "revision": "e5292658b9fe87e59cec",
    "url": "/js/app.d5fcda2e.js"
  },
  {
    "revision": "8830a97f2f1591c30fa4",
    "url": "/js/chunk-1d69d99a.fb3fe2b8.js"
  },
  {
    "revision": "bb852604472ecf37026c",
    "url": "/js/chunk-6b3e4ad5.18ff25d8.js"
  },
  {
    "revision": "94be27ce0a9f3d317ec3",
    "url": "/js/chunk-vendors.80779db8.js"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "4231739ba401746834f185e0496f8f66",
    "url": "/index.html"
  },
  {
    "revision": "e5292658b9fe87e59cec",
    "url": "/css/app.eb48c4ad.css"
  }
];